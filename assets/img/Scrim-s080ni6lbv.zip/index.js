<section id="Education">
                <div class="Education-left">
                    <p>Sekolah Menengah Pertama</p>
                      <p>Tahun</p>
                      <p>Alamat</p>
                    </div>
                    <div class="Education-right">
                      <p>SMPN 184 Jakarta Timur</p>
                      <p>2020-2023</p>
                      <p>Pekayon, Kec. Ps. Rebo, Kota Jakarta Timur, Daerah Khusus Ibukota Jakarta Timur</p>
                    </div>
                    <section id="Education">
                <div class="Education-left">
                    <p>Sekolah Menengah Kejuruan</p>
                      <p>Tahun</p>
                      <p>Alamat</p>
                    </div>
                    <div class="Education-right">
                      <p>SMK MAHADHIKA 4</p>
                      <p>2023-2026</p>
                      <p>Cijantung, Kec. Ps. Rebo, Kota Jakarta Timur, Daerah Khusus Ibukota Jakarta Timur</p>
                    </div>
             </section>